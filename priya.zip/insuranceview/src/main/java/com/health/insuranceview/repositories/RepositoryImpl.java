package com.health.insuranceview.repositories;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.health.insuranceview.contracts.IDAO;
import com.health.insuranceview.contracts.IRepository;
import com.health.insuranceview.models.CustomerData;
import com.health.insuranceview.models.Faq;
import com.health.insuranceview.models.FormData;
import com.health.insuranceview.models.HealthInsuranceApplication;
import com.health.insuranceview.models.InsurancePackages;
import com.health.insuranceview.models.InsurancePolicy;

@Repository
public  class RepositoryImpl implements IRepository {
	
	@Autowired
	IDAO idao;

	@Override
	public List<InsurancePolicy> getAllInsurancePolicies() {
		// TODO Auto-generated method stub
		return idao.getAllInsurancePolicies();
	}
	

	@Override
	public List<Faq> getAllFAQS() {
		// TODO Auto-generated method stub
		return idao.getAllFAQS();
	}


	@Override
	public List<InsurancePolicy> getCustomerInsurancePolicy() {
		// TODO Auto-generated method stub
		return idao.getCustomerInsurancePolicy();
	}


	@Override
	public List<InsurancePackages> getInsurancePackages() {
		// TODO Auto-generated method stub
		return idao.getInsurancePackages();
	}
	

	@Override
	public List<CustomerData> getCustomerDetails() {
		// TODO Auto-generated method stub
		return idao.getCustomerDetails();
	}

	@Override
	public void addCustomer(FormData loan) {
		// TODO Auto-generated method stub
		idao.addCustomer(loan);
	}


	@Override
	public List<Faq> getGeneralFAQS() {
		// TODO Auto-generated method stub
		return idao.getGeneralFAQS();
	}


	@Override
	public List<Faq> getCoverageandBenefitsFAQS() {
		// TODO Auto-generated method stub
		return idao.getCoverageandBenefitsFAQS();
	}



}
