package com.health.insuranceview.rowmappers;
	
	import org.springframework.jdbc.core.RowMapper;

import com.health.insuranceview.models.CustomerData;

import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.text.ParseException;
	import java.text.SimpleDateFormat;

		public class CustomerDataRowMapper implements RowMapper<CustomerData> {

		    @Override
		    public CustomerData mapRow(ResultSet rs, int rowNum) throws SQLException {
		        CustomerData customerData = new CustomerData();
		        customerData.setCust_id(rs.getLong("cust_id"));
		        customerData.setCust_fname(rs.getString("cust_fname"));
		        customerData.setCust_lname(rs.getString("cust_lname"));
		        customerData.setCust_dob(rs.getDate("cust_dob"));
		        customerData.setCust_address(rs.getString("cust_address"));
		        customerData.setCust_gender(rs.getString("cust_gender").charAt(0));
		        customerData.setCust_cdate(rs.getDate("cust_cdate"));
		        customerData.setCust_aadhar(rs.getLong("cust_aadhar"));
		        customerData.setCust_status(rs.getString("cust_status"));
		        customerData.setCust_luudate(rs.getDate("cust_luudate"));
		        customerData.setCust_luuser(rs.getInt("cust_luuser"));
		        customerData.setCust_user_id(rs.getLong("cust_user_id"));
		        return customerData;
		    }
		}


