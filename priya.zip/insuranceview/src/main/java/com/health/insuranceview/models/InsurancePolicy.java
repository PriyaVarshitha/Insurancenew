package com.health.insuranceview.models;


import java.util.Date;

public class InsurancePolicy {

	private int id;
	private int customerId;
	private Date creationDate;
	private int sumAssured;
	private Date applicableDate;
	private int insurancePackageId;
	private int yearlyPremiumAmount;
	private Date expirationDate;
	private int agentId;
	private String AppliName;
	private String AppliRelation;

	public InsurancePolicy() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int l) {
		this.id = l;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public int getSumAssured() {
		return sumAssured;
	}

	public void setSumAssured(int sumAssured) {
		this.sumAssured = sumAssured;
	}

	public Date getApplicableDate() {
		return applicableDate;
	}

	public void setApplicableDate(Date applicableDate) {
		this.applicableDate = applicableDate;
	}

	public int getInsurancePackageId() {
		return insurancePackageId;
	}

	public void setInsurancePackageId(int insurancePackageId) {
		this.insurancePackageId = insurancePackageId;
	}

	public int getYearlyPremiumAmount() {
		return yearlyPremiumAmount;
	}

	public void setYearlyPremiumAmount(int yearlyPremiumAmount) {
		this.yearlyPremiumAmount = yearlyPremiumAmount;
	}

	public Date getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	public int getAgentId() {
		return agentId;
	}

	public void setAgentId(int agentId) {
		this.agentId = agentId;
	}

	public String getAppliName() {
		return AppliName;
	}

	public void setAppliName(String appliName) {
		AppliName = appliName;
	}

	public String getAppliRelation() {
		return AppliRelation;
	}

	public void setAppliRelation(String appliRelation) {
		AppliRelation = appliRelation;
	}

	@Override
	public String toString() {
		return "InsurancePolicy [id=" + id + ", customerId=" + customerId + ", creationDate=" + creationDate
				+ ", sumAssured=" + sumAssured + ", applicableDate=" + applicableDate + ", insurancePackageId="
				+ insurancePackageId + ", yearlyPremiumAmount=" + yearlyPremiumAmount + ", expirationDate="
				+ expirationDate + ", agentId=" + agentId + "]";
	}

}

