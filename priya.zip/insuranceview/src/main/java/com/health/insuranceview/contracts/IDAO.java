package com.health.insuranceview.contracts;

import java.util.List;

import com.health.insuranceview.models.CustomerData;
import com.health.insuranceview.models.Faq;
import com.health.insuranceview.models.FormData;
import com.health.insuranceview.models.HealthInsuranceApplication;
import com.health.insuranceview.models.InsurancePackages;
import com.health.insuranceview.models.InsurancePolicy;

public interface IDAO {

	List<InsurancePolicy> getAllInsurancePolicies();
	
	List<Faq> getAllFAQS();

	List<InsurancePolicy> getCustomerInsurancePolicy();

	List<InsurancePackages> getInsurancePackages();

	List<CustomerData> getCustomerDetails();

	void addCustomer(FormData loan);

	List<Faq> getGeneralFAQS();

	List<Faq> getCoverageandBenefitsFAQS();


	
	

}
