package com.health.insuranceview.daos;

import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.health.insuranceview.contracts.IDAO;
import com.health.insuranceview.models.CustomerData;
import com.health.insuranceview.models.Faq;
import com.health.insuranceview.models.FormData;
import com.health.insuranceview.models.HealthInsuranceApplication;
import com.health.insuranceview.models.InsurancePackages;
import com.health.insuranceview.models.InsurancePolicy;
import com.health.insuranceview.rowmappers.*;
import com.health.insuranceview.rowmappers.FaqRowMapper;
import com.health.insuranceview.rowmappers.InsurancePackagesRowMapper;
import com.health.insuranceview.rowmappers.CustomerDataRowMapper;

@Component
public class DaoImpl implements IDAO {
	@Autowired
	JdbcTemplate jdbcTemplate;

	private String SQL_GET_INSURANCEPOLICIES = "select * from  insurancepolicies";

	private String SQL_GET_CUSTID_INSURANCEPOLICY = "select * from  InsurancePolicy ";

	private String SQL_GET_FAQS = "select * from FAQS";

	private String SQL_GET_GFAQS = "select * from HealthInsuranceFAQs where category='General' ";

	private String SQL_GET_CBFAQS = "select * from HealthInsuranceFAQs category='Coverage and Benefits' ";

	private String SQL_GET_INSURANCEPACKAGES = "select * from  InsurancePackages";

	private String SQL_GET_CUSTOMERDETAILS = "select * from InsuranceCustomers";

	@Override
	public List<InsurancePolicy> getAllInsurancePolicies() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query(SQL_GET_INSURANCEPOLICIES, new InsuranceDataRowMapper());
	}

	@Override
	public List<Faq> getAllFAQS() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query(SQL_GET_FAQS, new FaqRowMapper());
	}

	@Override
	public List<InsurancePolicy> getCustomerInsurancePolicy() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query(SQL_GET_CUSTID_INSURANCEPOLICY, new InsuranceDataRowMapper());
	}

	@Override
	public List<InsurancePackages> getInsurancePackages() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query(SQL_GET_INSURANCEPACKAGES, new InsurancePackagesRowMapper());
	}

	@Override
	public List<CustomerData> getCustomerDetails() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query(SQL_GET_CUSTOMERDETAILS, new CustomerDataRowMapper());
	}

	@Override
	public void addCustomer(FormData formData) {
		// TODO Auto-generated method stub
		long aadharLong = 0;
		try {
			String sql = "INSERT INTO customers (cust_fname, cust_lname, cust_dob, cust_address, cust_gender, cust_cdate, cust_aadhar, cust_status, cust_luudate, cust_luuser,cust_user_id) "
					+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";

			String aadharString = formData.getAadhar();
			try {
				aadharLong = Long.parseLong(aadharString);
				// Now 'aadharLong' contains the Aadhar number as a long
			} catch (NumberFormatException e) {
				// Handle the case where 'aadharString' is not a valid long
			}

			// Set values from FormData object
			jdbcTemplate.update(sql, formData.getfName(), formData.getlName(), formData.getDob(), formData.getAddress(),
					formData.getGender(), new Date(), // Assuming cust_cdate is the current date
					aadharLong, "Active", // Assuming cust_status is "Active"
					new Date(), // Assuming cust_luudate is the current date
					1,
					formData.getUser_id()// Assuming cust_luuser is 1 by default
			);
		} catch (Exception e) {
			e.printStackTrace();
			// Handle exceptions here
		}
		try {
			String sql = "INSERT INTO insurancepolicies1 (iplc_insp_id, iplc_yrly_prem_amount) " + "VALUES (?, ?)";

			jdbcTemplate.update(sql, formData.getId(), formData.getPrice());
		} catch (Exception e) {
			e.printStackTrace();
			// Handle exceptions here
		}

		try {
			String sql = "INSERT INTO insurancepolicycoveragemembers (iplc_id, ipcm_membername, ipcm_relation, ipcm_dob, ipcm_gender, ipcm_healthhistory) "
					+ "VALUES ((select iplc_id from insurancepolicies1 order by iplc_id limit 1),?, ?, ?, ?, ?)";

			// Assuming member.getGender() is a character (e.g., 'M' or 'F')
			char genderChar = formData.getGender();

			jdbcTemplate.update(sql,formData.getmName(), formData.getRelationship(), formData.getDob2(), genderChar,
					formData.getHealthHistory()

			);
		} catch (Exception e) {
			e.printStackTrace();
			// Handle exceptions here
		}

	}

	@Override
	public List<Faq> getGeneralFAQS() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query(SQL_GET_GFAQS, new FaqRowMapper());
	}

	@Override
	public List<Faq> getCoverageandBenefitsFAQS() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query(SQL_GET_CBFAQS, new FaqRowMapper());
	}

}
