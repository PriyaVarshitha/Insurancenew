package com.health.insuranceview.rowmappers;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import com.health.insuranceview.models.InsurancePolicy;

import org.springframework.jdbc.core.RowMapper;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

public class InsuranceDataRowMapper implements RowMapper<InsurancePolicy> {

    @Override
    public InsurancePolicy mapRow(ResultSet rs, int rowNum) throws SQLException {
    	InsurancePolicy insuranceData = new InsurancePolicy();
        insuranceData.setId(rs.getInt("id"));
        insuranceData.setCustomerId(rs.getInt("customerId"));
        insuranceData.setCreationDate(rs.getDate("creationDate"));
        insuranceData.setSumAssured(rs.getInt("sumAssured"));
        insuranceData.setApplicableDate(rs.getDate("applicableDate"));
        insuranceData.setInsurancePackageId(rs.getInt("insurancePackageId"));
        insuranceData.setYearlyPremiumAmount(rs.getInt("yearlyPremiumAmount"));
        insuranceData.setExpirationDate(rs.getDate("expirationDate"));
        insuranceData.setAgentId(rs.getInt("agentId"));
        insuranceData.setAppliName(rs.getString("AppliName"));
        insuranceData.setAppliRelation(rs.getString("AppliRelation"));
        return insuranceData;
    }
}


