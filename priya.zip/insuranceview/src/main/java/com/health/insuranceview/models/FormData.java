package com.health.insuranceview.models;

import java.sql.Date;

public class FormData {
	    private String fName;
	    private String lName;
	    private Date dob;
	    private String address;
	    private char gender;
	    private String aadhar;
	    private String mName;
	    private Date dob2;
	    private char gender1;
	   
		private String healthHistory;
	    private String relationship;
	    private int id;
	    private int price;
	    public int getUser_id() {
			return user_id;
		}


		public void setUser_id(int user_id) {
			this.user_id = user_id;
		}
		private int user_id;
	    
	    
		@Override
		public String toString() {
			return "FormData [fName=" + fName + ", lName=" + lName + ", dob=" + dob + ", address=" + address
					+ ", gender=" + gender + ", aadhar=" + aadhar + ", mName=" + mName + ", dob2=" + dob2
					+ ", healthHistory=" + healthHistory + ", relationship=" + relationship + ", id=" + id + ", price="
					+ price + "]";
		}
		
		
		 public char getGender1() {
				return gender1;
			}


			public void setGender1(char gender1) {
				this.gender1 = gender1;
			}
		
		public String getfName() {
			return fName;
		}
		public void setfName(String fName) {
			this.fName = fName;
		}
		public String getlName() {
			return lName;
		}
		public void setlName(String lName) {
			this.lName = lName;
		}
		public Date getDob() {
			return dob;
		}
		public void setDob(Date dob) {
			this.dob = dob;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public char getGender() {
			return gender;
		}
		public void setGender(char gender) {
			this.gender = gender;
		}
		public String getAadhar() {
			return aadhar;
		}
		public void setAadhar(String aadhar) {
			this.aadhar = aadhar;
		}
		public String getmName() {
			return mName;
		}
		public void setmName(String mName) {
			this.mName = mName;
		}
		public Date getDob2() {
			return dob2;
		}
		public void setDob2(Date dob2) {
			this.dob2 = dob2;
		}
		public String getHealthHistory() {
			return healthHistory;
		}
		public void setHealthHistory(String healthHistory) {
			this.healthHistory = healthHistory;
		}
		public String getRelationship() {
			return relationship;
		}
		public void setRelationship(String relationship) {
			this.relationship = relationship;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public int getPrice() {
			return price;
		}
		public void setPrice(int price) {
			this.price = price;
		}

	    // Constructors, getters, and setters for each field
}

